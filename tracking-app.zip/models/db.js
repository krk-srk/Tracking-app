const users = [
  { username: 'admin', password: 'admin123', role: 'admin' },
  { username: 'sales1', password: 'sales123', role: 'sales' },
  { username: 'user1', password: 'user123', role: 'user' }
];

const shipments = [
  { id: 'TRK1001', sender: 'John Doe', receiver: 'Alice', status: 'In Transit' }
];

module.exports = { users, shipments };