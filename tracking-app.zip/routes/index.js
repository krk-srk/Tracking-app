const express = require('express');
const router = express.Router();
const db = require('../models/db');

router.get('/', (req, res) => {
  res.redirect('/login');
});

router.get('/login', (req, res) => {
  res.render('login', { error: null });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.users.find(u => u.username === username && u.password === password);
  if (user) {
    req.session.user = user;
    res.redirect('/dashboard');
  } else {
    res.render('login', { error: 'Invalid credentials' });
  }
});

router.get('/dashboard', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  res.render('dashboard', { user: req.session.user });
});

router.get('/track', (req, res) => {
  const query = req.query.id;
  let shipment = null;
  if (query) {
    shipment = db.shipments.find(s => s.id === query);
  }
  res.render('track', { shipment, query });
});

router.get('/add-shipment', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'sales') return res.redirect('/login');
  res.render('add-shipment');
});

router.post('/add-shipment', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'sales') return res.redirect('/login');
  const { id, sender, receiver } = req.body;
  db.shipments.push({ id, sender, receiver, status: 'Booked' });
  res.redirect('/dashboard');
});

router.get('/admin', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'admin') return res.redirect('/login');
  res.render('admin', { shipments: db.shipments });
});

router.post('/admin/update-status', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'admin') return res.redirect('/login');
  const { id, status } = req.body;
  const shipment = db.shipments.find(s => s.id === id);
  if (shipment) {
    shipment.status = status;
  }
  res.redirect('/admin');
});

router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

module.exports = router;